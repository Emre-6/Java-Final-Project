/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lecture1;

/**
 *
 * @author sermet.onel
 */
class Course {
    private String coursecode;
    private String coursename;
    private Instructor courseInstructor;
    private Grade gradebook[];
    
    /*
    public Course (String coursecode, String coursename, Instructor courseInstructor){
        if(coursecode.startsWith("COMP")){
            this.coursecode = coursecode;
        }
        this.gradebook = new Grade[50];
        this.coursename = coursename;
        this.courseInstructor = courseInstructor;
    }
    */
    public String getCoursecode() {
        return coursecode;
    }

    public void setCoursecode(String coursecode) {
        this.coursecode = coursecode;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public Instructor getCourseInstructor() {
        return courseInstructor;
    }

    public void setCourseInstructor(Instructor courseInstructor) {
        this.courseInstructor = courseInstructor;
    }

    public Grade[] getGradebook() {
        return gradebook;
    }

    public void setGradebook(Grade[] gradebook) {
        this.gradebook = gradebook;
    }
}
