/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lecture1;

/**
 *
 * @author sermet.onel
 */
public class Lecture1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Course tempcourse = new Course();
        tempcourse.setCoursecode("COMP2215");
        tempcourse.setCoursename("Object Oriented Paradigms");
        
        Instructor ins = new Instructor();
        ins.setName("Sermet");
        ins.setAge(32);
        ins.setTitle("Res.Asst.");
        
        tempcourse.setCourseInstructor(ins);
        System.out.println(ins.title+" "+ins.name+" "+ins.getAge());
    }
    
}
